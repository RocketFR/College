#include <stdio.h>

int main()
 
{
	int contador = 500;
	
	do {
		
		printf ("\n%d", contador);
		contador--;
		}
	while (contador >=0  );
		
	return 0;
}
