#include <stdio.h>

int main(){
	
	int contador = 0;
	
	for (contador = 0; contador <=25; contador++)
		{
			 printf ("%d\n", contador);
		}
	return 0;
}
