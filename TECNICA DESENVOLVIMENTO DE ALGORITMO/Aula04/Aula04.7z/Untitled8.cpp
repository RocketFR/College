#include<iostream>

int main()
 
{
	int contador = 0;
	
	do {
		
		printf("\n%d", contador );
		contador++;
		}
	while (contador <= 1000);
		
	return 0;
}
