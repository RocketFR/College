#include <stdio.h>

int main()
 
{
	int contador = 5;
	
	do {
		
		printf ("\n%d", contador);
		contador++;
		}
	while (contador <= 200 );
		
	return 0;
}
