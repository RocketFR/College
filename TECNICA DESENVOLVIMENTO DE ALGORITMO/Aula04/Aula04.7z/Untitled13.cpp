#include <stdio.h>

int main(){
	
	int contador = 500;
	
	for (contador = 500; contador >=0; contador--)
		{
			 printf ("%d\n", contador);
		}
	return 0;
}

