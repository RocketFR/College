#include <stdio.h>

int main(){
	
	int contador = 0;
	
	for (contador = 0; contador <=1000; contador++)
		{
			 printf ("%d\n", contador);
		}
	return 0;
}


