#include <stdio.h>

int main(){
	
	int contador = 0;
	
	for (contador = 0; contador <=20; contador+=2)
		{
			 printf ("%d\n", contador);
		}
	return 0;
}

