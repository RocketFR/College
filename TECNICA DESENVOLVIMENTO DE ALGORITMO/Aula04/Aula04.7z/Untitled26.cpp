#include <stdio.h>
int main(){
     int numero = 1;   
     int par = 0;
          do{   
		      
            numero++;          
        	if (numero%2 == 0)  
        	par++;
                   
                     
    }while (numero < 30);
     
     printf ("a quantidade de numeros pares eh: %d", +par);  
     
    }
    


