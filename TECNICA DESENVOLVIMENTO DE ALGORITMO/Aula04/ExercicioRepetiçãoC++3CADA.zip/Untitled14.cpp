#include <stdio.h>

int main()
 
{
	int contador = 0;
	
	do {
		
		printf ("\n%d", contador);
		contador+=2;
		}
	while (contador <=20  );
		
	return 0;
}
