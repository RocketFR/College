#include <stdio.h>
int main(){
     int numero = 1;   
     int par = 0;
          while (numero < 30){   
		      
            numero++;          
        	if (numero%2 == 0)  
        	par++;
                   
                     
    }
     
     printf ("a quantidade de numeros pares eh: %d", +par);  
     
    }
    

