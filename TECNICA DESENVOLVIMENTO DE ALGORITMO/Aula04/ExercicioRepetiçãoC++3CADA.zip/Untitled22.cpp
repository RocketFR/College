#include <stdio.h>
int main(){
	
            int c = 0;
			int b = 0;
            for (int a = 0; a <= 10; a++)
            { 
              b = b + c;
              c++;
              
              
              printf ("\n%d", b);  
            
              
            }
			      
            
            
    }
    
      
