#include <stdio.h>
int main(){
	
	int a = 1;  
            
			int b = 0;
            do
            { 
              b = b + a;
              a++;
              
              printf ("\n%d", b);  
            
              
            }
			while (a <= 10);       
            
            
    }
    
      
