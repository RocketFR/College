#include <stdio.h>

int main(){
	
	int contador = 5;
	
	for (contador = 5; contador <=25; contador++)
		{
			 printf ("%d\n", contador);
		}
	return 0;
}

